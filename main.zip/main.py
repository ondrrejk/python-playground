import os
from math import sin,cos,dist,pi

R=3;I=1.25;F=10;SS=30;D=2*R;LP=(0,-1,-1)
points=[];rot=[0,0];chars=".-~:;!*&$@"
lp_m=dist(LP,(0,0,0))
LP=(LP[0]/lp_m,LP[1]/lp_m,LP[2]/lp_m)

for i in range(100):
    for j in range(30):
        a=i/100*pi*2
        b=j/30*pi*2
        x=sin(b)*I+R
        points.append(((sin(a)*x,cos(b)*I,cos(a)*x),(sin(a)*R,0,cos(a)*R)))

def clamp(x,minn,maxx):
    if x>maxx:
        return maxx
    if x<minn:
        return minn
    return x

os.system("cls")
while True:
    screen=[" "*SS]*SS
    np=[]
    for d in points:
        p=d[0]
        n=d[1]
        a=[p[0],cos(rot[0])*p[1]-sin(rot[0])*p[2],sin(rot[0])*p[1]+cos(rot[0])*p[2]]
        a=[cos(rot[1])*a[0]+sin(rot[1])*a[2],a[1],cos(rot[1])*a[2]-sin(rot[1])*a[0]]
        n=[n[0],cos(rot[0])*n[1]-sin(rot[0])*n[2],sin(rot[0])*n[1]+cos(rot[0])*n[2]]
        n=[cos(rot[1])*n[0]+sin(rot[1])*n[2],n[1],cos(rot[1])*n[2]-sin(rot[1])*n[0]]
        np.append((a,n))
    np=sorted(np,key=lambda x:x[0][2],reverse=True)
    for (p,n) in np:
        proj=[
        clamp(int(p[0]*F//(p[2]+D)+SS//2),0,SS-1),
        clamp(int(p[1]*F//(p[2]+D)+SS//2),0,SS-1)
        ]
        norm=[p[0]-n[0],p[1]-n[1],p[2]-n[2]]
        m=dist(norm,(0,0,0))
        norm=[norm[0]/m,norm[1]/m,norm[2]/m]
        dot=(LP[0]*norm[0]+LP[1]*norm[1]+LP[2]*norm[2]+1)/2
        char=chars[clamp(int(dot*8+0.1),0,len(chars)-1)]
        screen[proj[1]]=screen[proj[1]][:proj[0]]+char+screen[proj[1]][proj[0]+1:]
    ns=[]
    for l in screen:
        ns.append("")
        for i in l:
            ns[-1]+=i*2
    print("\033[2J\033[H", end="")
    print("\033[32m" + "\n".join(ns))
    rot[0]+=0.48/10
    rot[1]+=0.24/10