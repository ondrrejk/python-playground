from math import sin,cos,dist,pi
import pygame
import random

pygame.init()
screen=pygame.display.set_mode((500,500),pygame.FULLSCREEN)

R=3;I=1.5;F=1000;D=10*R;LP=(-1,-1,-1);Q=(50,25)
points=[];rot=[0,0]
lp_m=dist(LP,(0,0,0))
LP=(LP[0]/lp_m,LP[1]/lp_m,LP[2]/lp_m)

sprinkle_clrs=[
    (255,0,0),
    (0,255,0),
    (0,0,255)
]

halfA=1/Q[0]*pi
halfB=1/Q[1]*pi
for i in range(int(Q[0]/360*360)):
    for j in range(Q[1]):
        A=i/Q[0]*pi*2
        B=j/Q[1]*pi*2
        X=sin(B)*I+R

        al,ar=A-halfA,A+halfA
        bl,br=B-halfB,B+halfB
        xl,xr=sin(bl)*I+R,sin(br)*I+R

        color=(255,0,255)
        if j/Q[1]<0.25 or j/Q[1]>0.75:
            color=(211, 182, 156)
        if color==(255,0,255):
            if random.random() > 0.85:
                color=sprinkle_clrs[random.randint(0,len(sprinkle_clrs)-1)]

        points.append((
            (
                (sin(al)*xl,cos(bl)*I,cos(al)*xl),
                (sin(ar)*xl,cos(bl)*I,cos(ar)*xl),
                (sin(ar)*xr,cos(br)*I,cos(ar)*xr),
                (sin(al)*xr,cos(br)*I,cos(al)*xr)
            ),
            
            (sin(A)*R,0,cos(A)*R),
            (sin(A)*X,cos(B)*I,cos(A)*X),
            color
        ))

def clamp(x,minn,maxx):
    if x>maxx:
        return maxx
    if x<minn:
        return minn
    return x

while True:
    ss=screen.get_size()
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()
    screen.fill((0,0,0))
    np=[]
    for d in points:
        pp=[];n=d[1];b=d[2]
        n=[n[0],cos(rot[0])*n[1]-sin(rot[0])*n[2],sin(rot[0])*n[1]+cos(rot[0])*n[2]]
        n=[cos(rot[1])*n[0]+sin(rot[1])*n[2],n[1],cos(rot[1])*n[2]-sin(rot[1])*n[0]]
        b=[b[0],cos(rot[0])*b[1]-sin(rot[0])*b[2],sin(rot[0])*b[1]+cos(rot[0])*b[2]]
        b=[cos(rot[1])*b[0]+sin(rot[1])*b[2],b[1],cos(rot[1])*b[2]-sin(rot[1])*b[0]]
        for p in d[0]:
            a=[p[0],cos(rot[0])*p[1]-sin(rot[0])*p[2],sin(rot[0])*p[1]+cos(rot[0])*p[2]]
            a=[cos(rot[1])*a[0]+sin(rot[1])*a[2],a[1],cos(rot[1])*a[2]-sin(rot[1])*a[0]]
            pp.append(a)
        np.append((pp,n,b,d[3]))
    np=sorted(np,key=lambda x:x[2][2],reverse=True)
    for (pp,n,mid,color) in np:
        npp=[]
        clr=0
        for p in pp:
            proj=[
                clamp(p[0]*F/(p[2]+D)+ss[0]/2,0,ss[0]-1),
                clamp(p[1]*F/(p[2]+D)+ss[1]/2,0,ss[1]-1)
            ]
            norm=[p[0]-n[0],p[1]-n[1],p[2]-n[2]]
            m=dist(norm,(0,0,0))
            norm=[norm[0]/m,norm[1]/m,norm[2]/m]
            dot=LP[0]*norm[0]+LP[1]*norm[1]+LP[2]*norm[2]+0.2
            clr+=dot
            npp.append(proj)
        shade=clamp(clr,0,1)
        clr=(shade*color[0], shade*color[1], shade*color[2])
        pygame.draw.polygon(screen, clr, npp)
    rot[0] += 0.48/5
    rot[1] += 0.3/5

    pygame.display.flip()
    pygame.time.Clock().tick(60)